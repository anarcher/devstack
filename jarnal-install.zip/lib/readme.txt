This directory contains copies of the jar files needed to run jpedal and the license notice required for
distribution with the JCE jar from The Legion Of The Bouncy Castle (http://www.bouncycastle.org). We
recommend you visit their site for updates.

The jai files are part of the JAI download freely available from Sun Microsystems. These are the
bare files needed. We strongly recommend you download the full package which includes hardware
acceleration for several platforms.

These jars need to be added to the classpath for JPedal to run.


IDRsolutions ltd
September 2003